var datas = [18, 14, 21, 19, 23, 25, 17, 15, 18]
export const passengerTimeChartData = {
  type: "line",
  data: {
    labels: ["08H00", "08H30", "09H00", "09H30", "10H00", "10H30", "11H00", "11H30", "12H00"],
    datasets: [
      {
        label: "Evolution du nombre de passagers dans le temps",
        data: datas,
        backgroundColor: "rgba(71, 183,132,.5)",
        borderColor: "#47b784",
        borderWidth: 2
      }
    ]
  },
  options: {
    responsive: true,
    maintainAspectRatio: true,
    lineTension: 0.1,
    scales: {
      yAxes: [
        {
          ticks: {
            beginAtZero: true,
            padding: 25
          },
          gridLines: {
            display: true
          }
        }
      ],
      XAxes: [
        {
          ticks: {
            beginAtZero: true,
            padding: 25
          },
          gridLines: {
            display: false
          }
        }
      ]
    }
  }
}

export default passengerTimeChartData
