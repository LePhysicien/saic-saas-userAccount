<template>
  <AppLayout />
</template>

<script>
import AppLayout from "./layout/AppLayout"

export default {
  name: "App",
  data: () => ({
    //
  }),
  components: { AppLayout }
}
</script>
