<template>
  <v-card width="150">
    <v-row class="no-gutters">
      <div class="col-auto">
        <div class="cyan fill-height">&nbsp;</div>
      </div>
      <div class="col pa-3 py-4 cyan--text">
        <h5 class="text-truncate text-uppercase">Sales</h5>
        <h1>53%</h1>
      </div>
    </v-row>
  </v-card>
</template>

<script>
export default {
  name: "OneValueCard",

  data: () => ({})
}
</script>
