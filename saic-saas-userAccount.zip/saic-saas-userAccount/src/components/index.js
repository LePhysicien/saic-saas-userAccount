import OneValueCard from "./OneValueCard.vue"

export { OneValueCard }
