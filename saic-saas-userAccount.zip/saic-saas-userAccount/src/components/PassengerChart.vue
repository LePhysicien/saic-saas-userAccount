<template>
  <div>
    <canvas id="passenger-chart"></canvas>
  </div>
</template>
<script>
import Chart from "chart.js/auto"
export default {
  name: "PassengerChart",
  props: { datas: Array },
  data() {
    return {}
  },

  mounted() {
    const ctx = document.getElementById("passenger-chart")
    new Chart(ctx, {
      type: "line",
      data: {
        labels: ["Départ", "Arrêt 1", "Arrêt 2", "Arrêt 3", "Arrêt 4", "Arrêt 5", "Arrêt 6", "Arrêt 7", "Terminus"],
        datasets: [
          {
            label: "Evolution du nombre de passagers par arrêt",
            data: this.datas,
            backgroundColor: "rgba(71, 183,132,.5)",
            borderColor: "#47b784",
            borderWidth: 2
          }
        ]
      },
      options: {
        responsive: true,
        lineTension: 0.1,
        scales: {
          yAxes: [
            {
              ticks: {
                beginAtZero: true,
                padding: 25
              }
            }
          ]
        }
      }
    })
  }
}
</script>
