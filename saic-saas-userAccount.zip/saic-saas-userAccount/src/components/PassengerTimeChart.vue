<template>
  <div>
    <canvas id="passenger-time-chart"></canvas>
  </div>
</template>
<script>
import Chart from "chart.js/auto"
export default {
  name: "PassengerChart",
  props: { datas: Array },
  data() {
    return {
      //datas: [14, 15, 25, 21, 23, 27, 22, 19, 18]
    }
  },

  mounted() {
    //console.log(this.datas)
    //console.log(typeof Array.from(this.datas))
    const ctx = document.getElementById("passenger-time-chart").getContext("2d")
    new Chart(ctx, {
      type: "line",
      data: {
        labels: ["08H00", "08H30", "09H00", "09H30", "10H00", "10H30", "11H00", "11H30", "12H00"],
        datasets: [
          {
            label: "Evolution du nombre de passagers dans le temps",
            data: this.datas,
            backgroundColor: "rgba(71, 183,132,.5)",
            borderColor: "#47b784",
            borderWidth: 2
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: true,
        lineTension: 0.1,
        scales: {
          yAxes: [
            {
              ticks: {
                beginAtZero: true,
                padding: 25
              },
              gridLines: {
                display: true
              }
            }
          ],
          XAxes: [
            {
              ticks: {
                beginAtZero: true,
                padding: 25
              },
              gridLines: {
                display: false
              }
            }
          ]
        }
      }
    })
  }
}
</script>
