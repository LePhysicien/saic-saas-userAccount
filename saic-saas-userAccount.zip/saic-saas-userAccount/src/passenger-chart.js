export const passengerChartData = {
  type: "line",
  data: {
    labels: ["Départ", "Arrêt 1", "Arrêt 2", "Arrêt 3", "Arrêt 4", "Arrêt 5", "Arrêt 6", "Arrêt 7", "Terminus"],
    datasets: [
      {
        label: "Evolution du nombre de passagers par arrêt",
        data: [5, 9, 18, 14, 21, 25, 15, 13, 7],
        backgroundColor: "rgba(71, 183,132,.5)",
        borderColor: "#47b784",
        borderWidth: 2
      }
    ]
  },
  options: {
    responsive: true,
    lineTension: 0.1,
    scales: {
      yAxes: [
        {
          ticks: {
            beginAtZero: true,
            padding: 25
          }
        }
      ]
    }
  }
}

export default passengerChartData
