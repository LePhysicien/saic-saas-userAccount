const dashboardStore = {
  namespaced: true,
  state: {
    test: 3
  },
  getters: {},
  mutations: {},
  actions: {}
}

export default dashboardStore
