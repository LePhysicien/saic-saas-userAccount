const userStore = {
  namespaced: true,
  state: {
    isAuthenticated: false,
    firstName: "Thomas",
    lastName: ""
  },
  getters: {},
  mutations: {
    setAuthenticated(state) {
      state.isAuthenticated = true
    }
  },
  actions: {
    async login({ commit }) {
      commit("setAuthenticated")
    }
  }
}

export default userStore
