import Vue from "vue"
import Vuex from "vuex"
import dashboardStore from "./dashboardStore"
import userStore from "./userStore"

Vue.use(Vuex)

export default new Vuex.Store({
  modules: {
    dashboard: dashboardStore,
    user: userStore
  },
  state: {
    showSidebar: true,
    selectedSidebarItem: "",
    isAuthenticated: false
  },
  getters: {},
  mutations: {
    toggleSidebar(state) {
      state.showSidebar = !state.showSidebar
    },
    setSidebarItem(state, item) {
      state.selectedSidebarItem = item
    }
  },
  actions: {}
})
