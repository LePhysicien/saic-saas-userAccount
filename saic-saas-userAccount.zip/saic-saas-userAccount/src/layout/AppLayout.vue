<template>
  <component :is="layout">
    <router-view></router-view>
  </component>
</template>

<script>
const defaultLayout = "DashboardLayout"
export default {
  name: "AppLayout",
  computed: {
    layout() {
      const layout = this.$route.meta.layout || defaultLayout
      return () => import(`@/layout/${layout}.vue`)
    }
  }
}
</script>
