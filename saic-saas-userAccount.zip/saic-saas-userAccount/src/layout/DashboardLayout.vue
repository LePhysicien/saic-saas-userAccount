<template>
  <v-app>
    <NavBar />
    <SideBar />
    <v-main>
      <v-container class="px-4 py-0 fill-height" fluid>
        <v-row class="fill-height">
          <v-col>
            <transition name="fade">
              <slot />
            </transition>
          </v-col>
        </v-row>
      </v-container>
    </v-main>
  </v-app>
</template>

<script>
import NavBar from "../layout/NavBar.vue"
import SideBar from "../layout/SideBar.vue"

export default {
  name: "DashboardLayout",
  components: { NavBar, SideBar }
}
</script>
