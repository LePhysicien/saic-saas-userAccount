<template>
  <v-navigation-drawer app :value="showSidebar" class="elevation-2" clipped>
    <v-list dense>
      <v-list-item>
        <v-list-item-action>
          <v-icon @click.stop="toggleSidebar">mdi-chevron-left</v-icon>
        </v-list-item-action>
      </v-list-item>
    </v-list>
    <v-list nav>
      <v-list-item-group v-if="isDashboard" mandatory>
        <v-list-item v-for="item in dashboardMenu" :key="item.title" link :to="item.href">
          <v-list-item-icon>
            <v-icon :color="item.color">{{ item.icon }}</v-icon>
          </v-list-item-icon>
          <v-list-item-content>
            <v-list-item-title class="primary--text">{{ item.title }}</v-list-item-title>
          </v-list-item-content>
        </v-list-item>
      </v-list-item-group>
      <v-list-item-group v-if="isConfig" mandatory>
        <v-list-item v-for="item in configMenu" :key="item.title" link :to="item.href">
          <v-list-item-icon>
            <v-icon color="primary">{{ item.icon }}</v-icon>
          </v-list-item-icon>
          <v-list-item-content>
            <v-list-item-title class="primary--text">{{ item.title }}</v-list-item-title>
          </v-list-item-content>
        </v-list-item>
      </v-list-item-group>
    </v-list>
  </v-navigation-drawer>
</template>

<script>
export default {
  name: "SideBar",
  data() {
    return {
      sidebarMenu: true,
      toggleMini: true,
      dashboardMenu: [
        { title: "Global", href: "/dashboard/global", icon: "mdi-view-dashboard", color: "#F44336" },
        { title: "Buses", href: "/dashboard/buses", icon: "mdi-bus", color: "#A1887F" },
        { title: "Lines", href: "/dashboard/lines", icon: "mdi-ray-start-vertex-end", color: "warning" },
        { title: "Financial", href: "/dashboard/finance", icon: "mdi-chart-pie", color: "#388E3C" }
      ],
      configMenu: [
        { title: "Drivers", href: "/config/drivers", icon: "mdi-view-dashboard" },
        { title: "Buses", href: "/config/buses", icon: "mdi-image" },
        { title: "Itinerary", href: "/config/itinerary", icon: "mdi-image" },
        { title: "Pricing", href: "/config/pricing", icon: "mdi-help-box" }
      ],
      right: null
    }
  },
  computed: {
    mini() {
      return this.$vuetify.breakpoint.mdAndDown || this.toggleMini
    },
    showSidebar() {
      return this.$store.state.showSidebar
    },
    isDashboard() {
      return this.$route.path.includes("dashboard")
    },
    isConfig() {
      return this.$route.path.includes("config")
    }
  },
  methods: {
    toggleSidebar() {
      this.$store.commit("toggleSidebar")
    }
  }
}
</script>
