<template>
  <v-app-bar app color="primary" height="70" clipped-left dark>
    <div class="d-flex align-center">
      <v-app-bar-nav-icon @click.stop="toggleSidebar" class="mr-2"></v-app-bar-nav-icon>
      <a href="/">
        <v-img
          alt="SAIC Logo"
          class="shrink"
          contain
          :src="require('../assets/logo.svg')"
          transition="scale-transition"
          width="100"
        />
      </a>
    </div>

    <v-col>
      <v-row justify="center">
        <v-btn v-for="(link, i) in links" :key="i" text :to="link.href" class="subheading mx-3">{{ link.text }}</v-btn>
      </v-row>
    </v-col>
    <v-menu bottom :close-on-click="true" :close-on-content-click="true" :offset-y="true">
      <template v-slot:activator="{ on, attrs }">
        <v-avatar color="secondary" size="56" v-on="on" v-bind="attrs">
          <img src="https://cdn.vuetifyjs.com/images/john.jpg" alt="John" />
        </v-avatar>
      </template>

      <v-list width="250">
        <v-list-item-group color="primary">
          <v-list-item v-for="(item, i) in userMenuLinks" :key="i" :to="item.href" @click="handleClick(item.text)">
            <v-list-item-icon>
              <v-icon v-text="item.icon"></v-icon>
            </v-list-item-icon>
            <v-list-item-content>
              <v-list-item-title v-text="item.text"></v-list-item-title>
            </v-list-item-content>
          </v-list-item>
        </v-list-item-group>
      </v-list>
    </v-menu>
  </v-app-bar>
</template>

<script>
export default {
  name: "NavBar",

  data: () => ({
    sidebarMenu: false,
    links: [
      {
        text: "Dashboard",
        href: "/dashboard/global"
      },
      {
        text: "Camera",
        href: "/camera"
      },
      {
        text: "Configuration",
        href: "/config/drivers"
      }
    ],
    userMenuLinks: [
      { text: "Account", icon: "mdi-account", href: "/user-account" },
      { text: "Logout", icon: "mdi-logout", href: "" }
    ]
  }),
  methods: {
    toggleSidebar() {
      this.$store.commit("toggleSidebar")
    },
    handleClick(menuItem) {
      if (menuItem === "Logout") this.logout()
    },
    logout() {
      console.log("LOGOUT")
    }
  }
}
</script>

<style lang="scss" scoped>
.subheading {
  color: white;
  text-decoration: none;
  font-weight: 700;
  font-size: large;
  padding: 1rem;
  border-radius: 10px;
  transition: all 0.5s;
  &:hover {
    background-color: rgba(255, 255, 255, 0.2);
  }
}
</style>
