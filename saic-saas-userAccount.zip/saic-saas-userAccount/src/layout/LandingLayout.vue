<template>
  <v-app>
    <v-main>
      <div class="hero">
        <v-row align-content="center" justify="center">
          <slot />
        </v-row>
      </div>
    </v-main>
  </v-app>
</template>

<script>
export default {
  name: "LandingLayout"
}
</script>

<style scoped>
.hero {
  background: url("../assets/landing-bg.jpg") center center;
  background-size: cover;
  height: 100vh;
  width: 100vw;
}
.hero div.row {
  height: 100vh;
  color: white;
}
</style>
