<template>
  <v-container class="px-10">
    <v-row justify="space-between" class="my-10">
      <OneValueCard />
      <OneValueCard />
      <OneValueCard />
      <OneValueCard />
      <OneValueCard />
      <OneValueCard />
    </v-row>
    <v-row justify="space-between">
      <OneValueCard />
      <OneValueCard />
      <OneValueCard />
      <OneValueCard />
      <OneValueCard />
      <OneValueCard />
    </v-row>
  </v-container>
</template>

<script>
import { OneValueCard } from "@/components"
export default {
  name: "Global",

  components: {
    OneValueCard
  }
}
</script>
