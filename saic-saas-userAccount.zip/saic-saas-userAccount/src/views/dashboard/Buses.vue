<template>
  <v-container>
    <v-row justify="center">
      <v-col md="2">
        <v-select v-model="type" outlined :items="types" dense hide-details label="Select a bus"></v-select>
      </v-col>
      <v-col md="2">
        <v-menu
          ref="menu"
          v-model="menu"
          :close-on-content-click="false"
          :return-value.sync="date"
          transition="scale-transition"
          offset-y
          min-width="auto"
        >
          <template v-slot:activator="{ on, attrs }">
            <v-text-field
              outlined
              v-model="date"
              label="Period"
              append-icon="mdi-calendar"
              v-bind="attrs"
              v-on="on"
            ></v-text-field>
          </template>
          <v-date-picker v-model="date" no-title scrollable>
            <v-spacer></v-spacer>
            <v-btn text color="primary" @click="menu = false"> Cancel </v-btn>
            <v-btn text color="primary" @click="$refs.menu.save(date)"> OK </v-btn>
          </v-date-picker>
        </v-menu>
      </v-col>
    </v-row>
    <v-row justify="center" class="mb-5" v-for="data in busData" :key="data.name">
      <v-col md="2" v-if="data.name === type">
        <v-hover v-slot="{ hover }" open-delay="200">
          <v-card :elevation="hover ? 6 : 2" :class="{ 'on-hover': hover }" class="mx-5" width="210"
            ><v-list-item three-line>
              <v-list-item-content>
                <v-list-item-title class="text-h6 mb-5"> Voyageurs </v-list-item-title>
                <v-row>
                  <v-col :cols="6"
                    ><v-list-item-subtitle><v-icon size="50">mdi-account-multiple</v-icon></v-list-item-subtitle>
                  </v-col>
                  <v-col :cols="6">
                    <v-card-text class="text-h6">{{ data.passenger }}</v-card-text>
                  </v-col>
                </v-row>
              </v-list-item-content>
            </v-list-item>
          </v-card>
        </v-hover>
      </v-col>
      <v-col md="2" v-if="data.name === type">
        <v-hover v-slot="{ hover }" open-delay="200">
          <v-card :elevation="hover ? 6 : 2" :class="{ 'on-hover': hover }" class="mx-5" width="210"
            ><v-list-item three-line>
              <v-list-item-content>
                <v-list-item-title class="text-h6 mb-5"> Arrêts </v-list-item-title>
                <v-row>
                  <v-col :cols="6"
                    ><v-list-item-subtitle><v-icon size="50">mdi-map-marker</v-icon></v-list-item-subtitle>
                  </v-col>
                  <v-col :cols="6">
                    <v-card-text class="text-h6">{{ data.totalStop }}</v-card-text>
                  </v-col>
                </v-row>
              </v-list-item-content>
            </v-list-item>
          </v-card>
        </v-hover>
      </v-col>
      <v-col md="2" v-if="data.name === type">
        <v-hover v-slot="{ hover }" open-delay="200">
          <v-card :elevation="hover ? 6 : 2" :class="{ 'on-hover': hover }" class="mx-5" width="210"
            ><v-list-item three-line>
              <v-list-item-content>
                <v-list-item-title class="text-h6 mb-5"> Moyenne voyageurs </v-list-item-title>
                <v-row>
                  <v-col :cols="6"
                    ><v-list-item-subtitle><v-icon size="50">mdi-account-multiple</v-icon></v-list-item-subtitle>
                  </v-col>
                  <v-col :cols="6">
                    <v-card-text class="text-h6">{{ data.averagePassengers }}</v-card-text>
                  </v-col>
                </v-row>
              </v-list-item-content>
            </v-list-item>
          </v-card>
        </v-hover>
      </v-col>
      <v-col md="2" v-if="data.name === type">
        <v-hover v-slot="{ hover }" open-delay="200">
          <v-card :elevation="hover ? 6 : 2" :class="{ 'on-hover': hover }" class="mx-5" width="210"
            ><v-list-item three-line>
              <v-list-item-content>
                <v-list-item-title class="text-h6 mb-5"> Total voyageurs </v-list-item-title>
                <v-row>
                  <v-col :cols="6"
                    ><v-list-item-subtitle><v-icon size="50">mdi-account-multiple</v-icon></v-list-item-subtitle>
                  </v-col>
                  <v-col :cols="6">
                    <v-card-text class="text-h6">{{ data.totalpassengers }}</v-card-text>
                  </v-col>
                </v-row>
              </v-list-item-content>
            </v-list-item>
          </v-card>
        </v-hover>
      </v-col>
    </v-row>
    <v-row justify="center" class="mt-5" v-for="data in busData" :key="data.name">
      <v-col md="5" v-if="data.name === type">
        <v-hover v-slot="{ hover }" open-delay="200">
          <v-card :elevation="hover ? 6 : 2" :class="{ 'on-hover': hover }"
            ><passenger-time-chart :datas="data.graphData1" /></v-card
        ></v-hover>
      </v-col>
      <v-col md="5" v-if="data.name === type">
        <v-hover v-slot="{ hover }" open-delay="200">
          <v-card :elevation="hover ? 6 : 2" :class="{ 'on-hover': hover }"
            ><passenger-chart :datas="data.graphData2" /></v-card
        ></v-hover>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import PassengerChart from "@/components/PassengerChart.vue"
import PassengerTimeChart from "@/components/PassengerTimeChart.vue"
export default {
  name: "Buses",

  //:v-if="data.name === type" :v-for="data in busData" :key="data.name"
  components: { PassengerChart, PassengerTimeChart },

  data: () => ({
    date: new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().substr(0, 10),
    menu: false,
    modal: false,
    type: "Bus 001",
    types: ["Bus 001", "Bus 002", "Bus 003", "Bus 004", "Bus 005"],
    busData: [
      {
        name: "Bus 001",
        passenger: 17,
        totalpassengers: 82,
        averagePassengers: 15,
        graphData1: [18, 14, 21, 19, 23, 25, 17, 15, 18],
        graphData2: [5, 9, 18, 14, 21, 25, 15, 13, 7],
        totalStop: 15
      },
      {
        name: "Bus 002",
        passenger: 22,
        totalpassengers: 78,
        averagePassengers: 14,
        graphData1: [15, 16, 23, 21, 26, 22, 18, 19, 14],
        graphData2: [10, 12, 11, 14, 17, 23, 19, 18, 27],
        totalStop: 13
      },
      {
        name: "Bus 003",
        passenger: 19,
        totalpassengers: 94,
        averagePassengers: 16,
        graphData1: [14, 16, 21, 23, 25, 18, 17, 15, 18],
        graphData2: [5, 9, 18, 14, 21, 25, 15, 13, 7],
        totalStop: 17
      },
      {
        name: "Bus 004",
        passenger: 20,
        totalpassengers: 88,
        averagePassengers: 15,
        graphData1: [18, 14, 21, 19, 23, 25, 17, 15, 18],
        graphData2: [5, 9, 18, 14, 21, 25, 15, 13, 7],
        totalStop: 15
      },
      {
        name: "Bus 005",
        passenger: 14,
        totalpassengers: 69,
        averagePassengers: 15,
        graphData1: [18, 14, 21, 19, 23, 25, 17, 15, 18],
        graphData2: [5, 9, 18, 14, 21, 25, 15, 13, 7],
        totalStop: 15
      }
    ]
  })
}
</script>
