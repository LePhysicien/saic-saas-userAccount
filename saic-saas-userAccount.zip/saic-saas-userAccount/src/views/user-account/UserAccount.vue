<template>
  <div>
    <div>UserAccount</div>
    <div class="d-flex flex-column py-5 align-center">
      <div>
        <v-row class="align-center">
          <v-col lg="auto">
            <v-img
              src="https://cdn.vuetifyjs.com/images/john.jpg"
              alt="John"
              class="rounded-circle"
              width="180px"
            ></v-img>
          </v-col>
          <v-col lg="auto">
            <div class="text-left">
              <div>
                {{ user.firstName }} <span class="font-weight-black">{{ user.lastName }}</span>
              </div>
              <div class="my-5">
                {{ user.birthDate }}
              </div>
              <div>
                <v-chip color="primary">
                  {{ user.role }}
                </v-chip>
              </div>
            </div>
          </v-col>
        </v-row>
      </div>
      <div class="line-2x mt-5 d-flex flex-column justify-start">
        <div class="d-flex justify-space-between align-left">
          <span class="font-weight-bold">Téléphone:</span><span class="mx-2">{{ user.phone }}</span>
          <div>
            <v-dialog v-model="phonePopUp" transition="dialog-top-transition" persistent max-width="600px">
              <template v-slot:activator="{ on, attr }">
                <v-btn color="primary" v-bind="attr" v-on="on" icon><v-icon> mdi-pencil </v-icon></v-btn>
              </template>
              <v-card>
                <v-toolbar color="primary" dark>Change your phone nunber</v-toolbar>
                <v-card-text>
                  <v-container>
                    <v-row>
                      <v-col cols="12">
                        <v-form ref="formPhone" v-model="valid" lazy-validation>
                          <v-text-field
                            :rules="phoneRules"
                            :counter="15"
                            outlined
                            label="Telephone*"
                            required
                          ></v-text-field
                        ></v-form>
                      </v-col>
                    </v-row>
                  </v-container>
                </v-card-text>
                <v-card-actions>
                  <v-spacer></v-spacer>
                  <v-btn color="blue darken-1" text @click="reset"> Close </v-btn>
                  <v-btn color="blue darken-1" text @click="validatePhone"> Save </v-btn>
                </v-card-actions>
              </v-card>
            </v-dialog>
          </div>
        </div>
        <div class="d-flex justify-space-between align-center">
          <span class="font-weight-bold">Email:</span><span class="mx-2">{{ user.email }}</span>
          <div>
            <v-dialog v-model="emailPopUp" persistent max-width="600px">
              <template v-slot:activator="{ on, attr }">
                <v-btn color="primary" v-bind="attr" v-on="on" icon><v-icon> mdi-pencil </v-icon></v-btn>
              </template>
              <v-card>
                <v-toolbar color="primary" dark>Change your email</v-toolbar>
                <v-card-text>
                  <v-container>
                    <v-row>
                      <v-col cols="12">
                        <v-form ref="formEmail" v-model="valid" lazy-validation>
                          <v-text-field
                            :rules="emailRules"
                            :counter="15"
                            outlined
                            label="Email*"
                            required
                          ></v-text-field
                        ></v-form>
                      </v-col>
                    </v-row>
                  </v-container>
                </v-card-text>
                <v-card-actions>
                  <v-spacer></v-spacer>
                  <v-btn color="blue darken-1" text @click="reset"> Close </v-btn>
                  <v-btn color="blue darken-1" text @click="validateEmail"> Save </v-btn>
                </v-card-actions>
              </v-card>
            </v-dialog>
          </div>
        </div>
      </div>

      <v-dialog v-model="passwordPopUp" transition="dialog-bottom-transition" persistent max-width="450px">
        <template v-slot:activator="{ on, attrs }">
          <v-btn color="primary" class="text-center mt-5" dark v-bind="attrs" v-on="on"> CHANGE YOUR PASSWORD </v-btn>
        </template>
        <v-card>
          <v-toolbar color="primary" dark>Change your password</v-toolbar>

          <v-card-text>
            <v-form ref="formPass" v-model="valid" lazy-validation>
              <v-container>
                <v-row>
                  <v-col cols="12">
                    <v-text-field
                      outlined
                      :rules="passwordRules"
                      :counter="15"
                      v-model="password"
                      label="Password*"
                      type="password"
                      required
                    ></v-text-field>
                  </v-col>
                  <v-col cols="12">
                    <v-text-field
                      outlined
                      :counter="15"
                      :rules="newPasswordRules"
                      v-model="newPassword"
                      label="New password*"
                      type="password"
                      required
                    ></v-text-field>
                  </v-col>
                  <v-col cols="12">
                    <v-text-field
                      outlined
                      :counter="15"
                      :rules="confirmedPasswordRules"
                      v-model="confirmedPassword"
                      label="Confirmed password*"
                      type="password"
                      required
                    ></v-text-field>
                  </v-col>
                </v-row>
              </v-container>
              <small>*indicates required field</small>
            </v-form>
          </v-card-text>
          <v-card-actions>
            <v-spacer></v-spacer>
            <v-btn color="blue darken-1" text @click="reset"> Close </v-btn>
            <v-btn color="blue darken-1" text @click="validatePass"> Save </v-btn>
          </v-card-actions>
        </v-card>
      </v-dialog>
    </div>
  </div>
</template>

<script>
import Vuetify from "vuetify/lib/framework"
export default {
  name: "UserAccount",
  vuetify: new Vuetify(),
  component: {},
  data() {
    return {
      valid: true,
      passwordPopUp: false,
      emailPopUp: false,
      phonePopUp: false,
      password: "",
      phoneRules: [
        (v) => !!v || "Phone number is required",
        (v) => (v && v.length <= 10) || "Name must be less than 10 characters"
      ],
      emailRules: [(v) => !!v || "E-mail is required", (v) => /.+@.+\..+/.test(v) || "E-mail must be valid"],
      passwordRules: [
        (v) => !!v || "Password is required",
        (v) => (v && v.length <= 10) || "Name must be less than 10 characters"
      ],
      newPasswordRules: [
        (v) => !!v || "A new password is required",
        (v) => (v && v.length <= 10) || "Name must be less than 10 characters"
      ],
      confirmedPasswordRules: [
        (v) => !!v || "You need to confirm your password",
        (v) => (v && v.length <= 10) || "Name must be less than 10 characters"
      ],
      newPassword: "",
      confirmedPassword: "",
      user: {
        firstName: "Eric Loic",
        lastName: "Bassong",
        birthDate: "01/05/2003",
        role: "User",
        phone: +33788763256,
        email: "eric@yahoo.fr"
      }
    }
  },
  computed: {
    passwordErrors() {
      const errors = []
      return errors
    }
  },
  methods: {
    validatePass() {
      if (this.$refs.formPass.validate()) {
        console.log(this.$refs.formPass.validate())
        this.$refs.formPass.reset()
        this.passwordPopUp = false
      }
    },
    validateEmail() {
      if (this.$refs.formEmail.validate()) {
        this.$refs.formEmail.reset()
        this.emailPopUp = false
      }
    },
    validatePhone() {
      if (this.$refs.formPhone.validate()) {
        this.$refs.formPhone.reset()
        this.phonePopUp = false
      }
    },
    reset() {
      if (this.passwordPopUp) {
        this.passwordPopUp = false
        this.$refs.formPass.reset()
      } else if (this.phonePopUp) {
        this.phonePopUp = false
        this.$refs.formPhone.reset()
      } else if (this.emailPopUp) {
        this.emailPopUp = false
        this.$refs.formEmail.reset()
      }
    }
  }
}
</script>

<style scoped></style>
