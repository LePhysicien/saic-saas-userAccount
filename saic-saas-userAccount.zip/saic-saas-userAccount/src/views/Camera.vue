<template>
  <v-container class="px-10">
    <p>Video {{ test }}</p>
  </v-container>
</template>

<script>
export default {
  name: "Camera",
  data: () => ({
    sidebarToggled: false
  }),
  computed: {
    isShowSidebar() {
      return this.$store.state.showSidebar
    }
  },
  created() {
    console.log(this.isShowSidebar !== false)
    if (this.isShowSidebar === true) {
      this.$store.commit("toggleSidebar")
      this.sidebarToggled = true
    }
  },
  beforeDestroy() {
    if (this.sidebarToggled) {
      this.$store.commit("toggleSidebar")
    }
  }
}
</script>
