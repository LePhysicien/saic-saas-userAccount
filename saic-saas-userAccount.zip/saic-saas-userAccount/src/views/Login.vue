<template>
  <v-card class="mx-auto rounded-xl" width="400" height="600">
    <v-container class="fill-height">
      <v-row>
        <v-col>
          <v-img height="50" contain :src="require('../assets/logo-light.svg')" class="my-8"></v-img>
          <p class="text-h6 text-center blue-grey--text text--darken-1" justify="center">
            Smart Artificial Intelligence Counting
          </p>
        </v-col>
      </v-row>
      <v-row justify="center">
        <v-form ref="form" v-model="valid" class="form-container" lazy-validation>
          <v-text-field v-model="email" :rules="emailRules" label="E-mail" outlined required></v-text-field>

          <v-text-field
            v-model="password"
            :type="showPassword1 ? 'text' : 'password'"
            :rules="passwordRules"
            :append-icon="showPassword1 ? 'mdi-eye' : 'mdi-eye-off'"
            @click:append="showPassword1 = !showPassword1"
            label="Password"
            outlined
            required
          ></v-text-field>
        </v-form>
      </v-row>
      <v-row justify="center">
        <v-btn color="primary" @click="login"> Sign in </v-btn>
      </v-row>
      <v-row justify="center">
        <v-btn text color="primary" @click="revealRegistration = true"> Register </v-btn>
      </v-row>
    </v-container>

    <v-expand-transition>
      <v-card
        v-if="revealRegistration"
        class="transition-fast-in-fast-out v-card--reveal rounded-xl"
        style="height: 100%"
      >
        <v-container class="fill-height">
          <v-row justify="center">
            <p class="text-h4 mt-5">Create Account</p>
          </v-row>
          <v-row justify="center">
            <v-form ref="form" v-model="valid" class="form-container" lazy-validation>
              <v-text-field
                v-model="firstName"
                :rules="firstNameRules"
                label="Firstname"
                outlined
                required
              ></v-text-field>
              <v-text-field v-model="lastName" :rules="lastNameRules" label="Lastname" outlined required></v-text-field>
              <v-text-field v-model="email" :rules="emailRules" label="E-mail" outlined required></v-text-field>

              <v-text-field
                v-model="password"
                :type="showPassword2 ? 'text' : 'password'"
                :rules="passwordRules"
                :append-icon="showPassword2 ? 'mdi-eye' : 'mdi-eye-off'"
                @click:append="showPassword2 = !showPassword1"
                label="Password"
                outlined
                required
              ></v-text-field>
            </v-form>
          </v-row>
          <v-row justify="center">
            <v-btn color="primary" @click="register"> Register </v-btn>
          </v-row>
          <v-row justify="center">
            <v-btn text color="primary" @click="revealRegistration = false"> Sign in </v-btn>
          </v-row>
        </v-container>
      </v-card>
    </v-expand-transition>
  </v-card>
</template>

<script>
export default {
  name: "Login",
  data: () => ({
    revealRegistration: false,
    valid: true,
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    showPassword1: false,
    showPassword2: false,
    firstNameRules: [
      (v) => !!v || "Firstname is required",
      (v) => (v && v.length <= 12) || "Firstname must be less than 12 characters"
    ],
    lastNameRules: [
      (v) => !!v || "Lastname is required",
      (v) => (v && v.length <= 20) || "Lastname must be less than 20 characters"
    ],
    emailRules: [(v) => !!v || "E-mail is required", (v) => /.+@.+\..+/.test(v) || "E-mail must be valid"],
    passwordRules: [
      (v) => !!v || "Password is required",
      (v) => (v && v.length >= 8) || "Password must be greater than 8 characters"
    ]
  }),

  methods: {
    validate() {
      this.$refs.form.validate()
    },
    reset() {
      this.$refs.form.reset()
    },
    resetValidation() {
      this.$refs.form.resetValidation()
    },
    login() {
      this.$store.dispatch("user/login")
      this.$router.push({ path: "/dashboard/global" })
    },
    register() {
      this.$store.dispatch("user/register")
    }
  }
}
</script>

<style>
.v-card--reveal {
  bottom: 0;
  opacity: 1 !important;
  position: absolute;
  width: 100%;
}
.form-container {
  width: 80%;
}
.column {
  display: flex;
  flex-flow: column wrap;
  justify-content: space-around;
  height: 100%;
}
</style>
