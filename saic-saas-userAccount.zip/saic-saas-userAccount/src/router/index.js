import Vue from "vue"
import VueRouter from "vue-router"
import Global from "@/views/dashboard/Global.vue"
import Buses from "@/views/dashboard/Buses.vue"
import Login from "@/views/Login.vue"
import Camera from "@/views/Camera"
import store from "@/store"
import UserAccount from "@/views/user-account/UserAccount.vue"

Vue.use(VueRouter)

const routes = [
  {
    path: "/",
    name: "Home",
    component: Login,
    meta: {
      layout: "LandingLayout"
    }
  },
  {
    path: "/login",
    name: "Login",
    component: Login,
    meta: {
      layout: "LandingLayout"
    }
  },
  {
    path: "/camera",
    name: "Camera",
    component: Camera,
    meta: {
      requiresAuth: true
    }
  },
  {
    path: "/dashboard/global",
    name: "Global",
    component: Global,
    meta: {
      requiresAuth: true
    }
  },
  {
    path: "/dashboard/buses",
    name: "Buses",
    component: Buses,
    meta: {
      requiresAuth: true
    }
  },
  {
    path: "/user-account",
    name: "UserAccount",
    component: UserAccount,
    meta: {
      requiresAuth: true
    }
  }
]

const router = new VueRouter({
  mode: "history",
  base: process.env.BASE_URL,
  routes
})

router.beforeEach((to, from, next) => {
  if (to.matched.some((record) => record.meta.requiresAuth)) {
    if (store.state.user.isAuthenticated) {
      next()
    } else {
      next({
        name: "Login"
      })
    }
  } else {
    next()
  }
})
export default router
